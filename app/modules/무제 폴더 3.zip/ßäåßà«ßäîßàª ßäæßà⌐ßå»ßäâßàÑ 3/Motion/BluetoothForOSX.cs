﻿#if (UNITY_STANDALONE_OSX && !UNITY_EDITOR) || DEBUG_OSX || UNITY_EDITOR_OSX
#define OS_OSX
#endif

using UnityEngine;
using System;
using System.Collections;
using System.IO.Ports;
using System.Threading;
using System.Collections.Generic;
using System.IO;


#if OS_OSX
public class BluetoothForOSX : BluetoothBase
{
    // Fields
    public BluetoothDeviceScript device;
    private string deviceUUID;


    // Initializer
    public BluetoothForOSX(MonoBehaviour mono)
        : base(mono)
    {
        mono.StartCoroutine(_ReadEvent());
    }


    private IEnumerator _ReadEvent()
    {
        while (true)
        {
            if (!isDownloadingBigData)
            {
                if (SerialPortCTRL.port != null)
                {
                    try
                    {
                        while (true)
                        {
                            int data = SerialPortCTRL.port.ReadByte();
                            if (data > -1)
                            {
                                byte b = (byte)data;
                                readBuffer.Enqueue(b);
                            }
                            else
                            {
                                Debug.LogWarning("Maybe port is unplugged!");
                                SerialPortCTRL.port = null;
                                MotionCommanderBase.OnError(COMM_RESULT.TX_FAIL);
                            }
                        }
                    }
                    catch (TimeoutException) { }
                    catch (InvalidOperationException)
                    {
                        //Debug.LogWarning("Not Opened! " + e);
                    }
                    catch (Exception) { }
                    //Debug.Log(DateTime.Now + ":" + GetLogString(readBuffer.ToArray()));
                }
            }

            yield return null;
        }
    }


    // Properties
    public override int WriteTimeout { get; set; }
    public override int ReadTimeout { get; set; }
    public override int BufferCount { get { return readBuffer.Count; } }
    public override bool IsSupportedBLE { get { return BluetoothDeviceScript.IsSupportedBLE; } }
    public override bool IsSupportedClassic { get { return true; } }


    // Methods
    public override void SetBluetoothEnable(bool enable, Action<string> action)
    {
        if (Application.isEditor && !PlatformPluginsManager.IsOSX) return;
        isEnablingBluetooth = true;

        if (enable)
        {
            if (!isEnabledBluetooth)
                device = BluetoothLEHardwareInterface.Initialize(true, false, delegate() { action(bool.TrueString); }, delegate() { action(bool.FalseString); }, null);
            else
                action(bool.TrueString);
        }
        else
        {
            if (isEnabledBluetooth)
                BluetoothLEHardwareInterface.DeInitialize();
            device = null;
        }
    }
    public override string[] DoSearchBluetooth(Action<string> action)
    {
        if (Application.isEditor && !PlatformPluginsManager.IsOSX) return null;

        if (device != null)
        {
            BluetoothLEHardwareInterface.ScanForPeripheralsWithServices(
                new string[] { BleUUID.service },
                delegate(string uuid, string name, string address)
                {
                    action(new BleInfo(uuid, name, address).ToString());
                }
            );
        }

        return PlatformPluginsManager.GetSerialPorts();
    }

    public override IEnumerator DoConnect(string portName, Action<string> action)
    {
        if (Application.isEditor && !PlatformPluginsManager.IsOSX) yield break;
        isConnectingBluetooth = true;

        if (BluetoothType == BluetoothGeneration.BLE)
        {
            string portAddress = portName.SplitNewline()[1];
            string uuid = device.FindUuid(portAddress);

            BluetoothLEHardwareInterface.Log("DoConnectBluetooth " + portAddress + ":" + uuid);
            BluetoothLEHardwareInterface.RemoveCharacteristics();
            BluetoothLEHardwareInterface.ConnectToPeripheral(
                uuid, null, null,
                delegate(string resultUuid, string resultService, string resultCharacteristic)
                {
                    //@@ OSX에서 Unknown Device로 검색되기 때문에 아래와 같이 UUID 구별해야함
                    if (deviceUUID != resultUuid && resultCharacteristic.ToUpper().Contains("6E400003"))
                    {
                        Debug.Log("SUBSCRIBE");

                        action(resultUuid == uuid ? bool.TrueString : bool.FalseString);

                        if (deviceUUID != resultUuid)
                        {
                            deviceUUID = resultUuid;

                            BluetoothLEHardwareInterface.Log("SubscribeCharacteristic:" + deviceUUID + ":" + BleUUID.service + ":" + BleUUID.rxCharacteristic);
                            BluetoothLEHardwareInterface.SubscribeCharacteristic(deviceUUID, BleUUID.service, BleUUID.rxCharacteristic, OnNotifyState, OnReceiveData);
                        }

                        device.DiscoveredCharacteristicAction = null;
                    }
                }
            );
            yield break;
        }
        else if (BluetoothType == BluetoothGeneration.Classic)
        {
            string[] split = portName.SplitNewline();
            string portAddress = PlatformPluginsManager.ConvertAddressPrefix(split[1]);
            isMicroUSB = split[0] == Keyword.Device.MICRO_USB_PORT;

            bool threadIsDone = false;
            bool connected = false;
            ThreadStart threadStart = new ThreadStart(delegate()
            {
                try
                {
                    connected = SerialPortCTRL.openPort(portAddress);
                    SerialPortCTRL.port.Write(Keyword.Command.v0);
                    PlatformPluginsManager.bluetooth.SetBaudrate(SerialPortCTRL.DEFAULT_BAUDRATE);
                }
                catch (Exception e)
                {
                    SerialPortCTRL.closePort();
                    connected = false;

                    Debug.LogWarning("Not Open! " + e);
                }
                threadIsDone = true;
            });
            Thread thread = new Thread(threadStart);
            thread.IsBackground = true;
            thread.Start();
            while (!threadIsDone) yield return null;
            thread.Abort();

            action(connected ? bool.TrueString : bool.FalseString);
            Debug.Log("Connect: " + portAddress + ":" + connected);
        }
    }
    public override IEnumerator WaitForInitialized()
    {
        BluetoothLEHardwareInterface.Log("WaitForInitialized");
        // bt-410 initialization & test time 2000~3000ms
        yield return new WaitForSeconds(BluetoothType == BluetoothGeneration.BLE ? 3.0f : 0.5f);
        DiscardInBuffer();
    }
    public override IEnumerator DoDisconnect()
    {
        if (BluetoothType == BluetoothGeneration.BLE)
        {
            BluetoothLEHardwareInterface.Log("DoDisconnect : " + deviceUUID + ":" + IsConnected);

            Action<string> action = delegate(string uuid)
            {
                deviceUUID = null;
                IsConnected = false;
            };

            BluetoothLEHardwareInterface.StopScan();
            yield return new WaitForSeconds(1.0f);
            BluetoothLEHardwareInterface.UnSubscribeCharacteristic(deviceUUID, BleUUID.service, BleUUID.rxCharacteristic, OnNotifyState);
            BluetoothLEHardwareInterface.DisconnectPeripheral(deviceUUID, action);

            int accumulateTime = 0;
            int deltaTime = Mathf.RoundToInt(1000f / (float)Application.targetFrameRate);
            while (IsConnected)
            {
                accumulateTime += deltaTime;
                if (accumulateTime > 1000)
                {
                    action(null);
                    yield break;
                }
                yield return null;
            }
        }
        else if (BluetoothType == BluetoothGeneration.Classic)
        {
            SerialPortCTRL.closePort();
            yield break;
        }
    }
    public override bool IsOpen()
    {
        if (BluetoothType == BluetoothGeneration.BLE)
            return BluetoothLEHardwareInterface.IsOpen;
        else if (BluetoothType == BluetoothGeneration.Classic)
            return SerialPortCTRL.port != null && SerialPortCTRL.port.IsOpen;

        return false;
    }

    public override IEnumerator DoDownloadBigData(byte[] bigBuffer, Action<string> action, Action<string> progressResult)
    {
        isDownloadingBigData = true;

        if (BluetoothType == BluetoothGeneration.BLE)
        {
            COMM_RESULT retVal = COMM_RESULT.TX_SUCCESS;
            int unitSize = 40; // = 32
            GC.Collect();
            yield return new WaitForSeconds(0.2f);
            DiscardInBuffer();

            if (bigBuffer != null && bigBuffer.Length >= unitSize)
            {
                int ix = 0;
                int jx = 0;
                int ixMax = bigBuffer.Length - unitSize;
                byte[] unitBuffer = new byte[unitSize];
                for (ix = 0; ix < ixMax; ix += unitSize)
                {
                    Array.Copy(bigBuffer, ix, unitBuffer, 0, unitSize);
                    if (!WriteSafe(unitBuffer, unitBuffer.Length, false))
                    {
                        retVal = COMM_RESULT.TX_FAIL;
                        break;
                    }

                    jx += unitSize;
                    if (jx >= 128)
                    {
                        progressResult(ix.ToString());
                        jx = 0;
                    }

                    if (BufferCount > 0)
                    {
                        CoroutineString log = new CoroutineString();
                        yield return mono.StartCoroutine(ReadExistingStringAsync(log));
                        BluetoothLEHardwareInterface.Log("Stop Download : " + ix + ":" + log.data);
                        retVal = COMM_RESULT.TX_FAIL;
                        break;
                    }

                    yield return null;
                }

                if (retVal == COMM_RESULT.TX_SUCCESS)
                {
                    if (bigBuffer.Length > ix)
                    {
                        byte[] remained = new byte[bigBuffer.Length - ix];
                        Array.Copy(bigBuffer, ix, remained, 0, remained.Length);
                        if (!WriteSafe(remained, remained.Length, true))
                            retVal = COMM_RESULT.TX_FAIL;
                    }
                }
            }

            if (retVal == COMM_RESULT.TX_SUCCESS)
            {
                action(bool.TrueString);
            }
            else
            {
                yield return new WaitForSeconds(4.0f);
                DiscardInBuffer();
                action(bool.FalseString);
            }
        }
        else if (BluetoothType == BluetoothGeneration.Classic)
        {
            COMM_RESULT retVal = COMM_RESULT.TX_SUCCESS;

            // @@ OSX Timing Test
            int unitSize = isMicroUSB ? 16 : 32;
            int delay = isMicroUSB ? 2 : 8;
            bool threadIsDone = false;
            DiscardInBuffer();

            ThreadStart threadStart = new ThreadStart(delegate()
            {
                if (bigBuffer != null && bigBuffer.Length >= unitSize)
                {
                    int ix = 0;
                    int jx = 0;
                    int ixMax = bigBuffer.Length - unitSize;
                    byte[] unitBuffer = new byte[unitSize];

                    try
                    {
                        for (ix = 0; ix < ixMax; ix += unitSize)
                        {
                            if (SerialPortCTRL.port.DsrHolding)
                            {
                                Debug.LogWarning("Maybe port is unplugged!");
                                break;
                            }

                            Array.Copy(bigBuffer, ix, unitBuffer, 0, unitSize);
                            Write(unitBuffer, unitBuffer.Length, false);

                            jx += unitSize;
                            if (jx >= 128)
                            {
                                progressResult(ix.ToString());
                                jx = 0;
                            }

                            //if (!isMicroUSB)
                            Thread.Sleep(delay);
                        }

                        if (bigBuffer.Length > ix)
                        {
                            byte[] remained = new byte[bigBuffer.Length - ix];
                            Array.Copy(bigBuffer, ix, remained, 0, remained.Length);
                            Write(remained, remained.Length);
                        }
                    }
                    catch (TimeoutException e)
                    {
                        retVal = COMM_RESULT.TX_FAIL;
                        Debug.LogWarning(retVal + ":" + e);
                    }
                    catch (Exception e)
                    {
                        retVal = COMM_RESULT.UNKNOWN;
                        Debug.LogWarning(retVal + ":" + e);
                    }
                }

                threadIsDone = true;
            });

            Thread thread = new Thread(threadStart);
            thread.IsBackground = true;
            thread.Priority = System.Threading.ThreadPriority.Highest;
            thread.Start();
            while (!threadIsDone) yield return null;
            thread.Abort();

            if (retVal == COMM_RESULT.TX_SUCCESS)
            {
                action(bool.TrueString);
            }
            else
            {
                yield return new WaitForSeconds(4.0f);
                DiscardInBuffer();
                action(bool.FalseString);
                if (retVal == COMM_RESULT.TX_FAIL)
                {
                    if (MotionCommanderBase.ControllerName == Keyword.Controller.CM510 || MotionCommanderBase.ControllerName == Keyword.Controller.CM700)
                        WriteLineSafe(Keyword.Command.go);

                    MotionCommanderBase.OnError(retVal);
                }
            }
        }
    }

    public override void Write(byte[] buffer, int count, bool debug = true)
    {
        if (BluetoothType == BluetoothGeneration.BLE)
        {
            if (debug) BluetoothLEHardwareInterface.Log("Write : " + buffer.Length + " : " + GetLogString(buffer));
            if (buffer.Length > count)
            {
                byte[] buffer2 = new byte[count];
                Array.Copy(buffer, buffer2, count);
                BluetoothLEHardwareInterface.WriteCharacteristic(deviceUUID, BleUUID.service, BleUUID.txCharacteristic, buffer2, buffer2.Length, false, null);
            }
            else
            {
                BluetoothLEHardwareInterface.WriteCharacteristic(deviceUUID, BleUUID.service, BleUUID.txCharacteristic, buffer, buffer.Length, false, null);
            }
        }
        else if (BluetoothType == BluetoothGeneration.Classic)
        {
            if (SerialPortCTRL.port == null) throw new TimeoutException();
            if (debug) BluetoothLEHardwareInterface.Log("Write : " + buffer.Length + " : " + GetLogString(buffer));
            SerialPortCTRL.port.Write(buffer, 0, count);
        }
    }
    public override void Write(string data, bool debug = true)
    {
        if (BluetoothType == BluetoothGeneration.BLE)
        {
            byte[] buffer = BluetoothBase.GetBytes(data);
            if (debug) BluetoothLEHardwareInterface.Log("Write : " + data + ":" + GetLogString(buffer));
            BluetoothLEHardwareInterface.WriteCharacteristic(deviceUUID, BleUUID.service, BleUUID.txCharacteristic, buffer, buffer.Length, false, null);
        }
        else if (BluetoothType == BluetoothGeneration.Classic)
        {
            if (SerialPortCTRL.port == null) throw new TimeoutException();
            if (debug) BluetoothLEHardwareInterface.Log("Write : " + data);
            SerialPortCTRL.port.Write(data);
        }
    }
    public override void WriteLine(string data, bool debug = true)
    {
        if (BluetoothType == BluetoothGeneration.BLE)
        {
            byte[] buffer = string.IsNullOrEmpty(data) ? new byte[] { 0x0D, 0x0A } : BluetoothBase.GetBytes(string.Format("{0}\n", data));
            if (debug) BluetoothLEHardwareInterface.Log("WriteLine : " + data + ":" + GetLogString(buffer));
            BluetoothLEHardwareInterface.WriteCharacteristic(deviceUUID, BleUUID.service, BleUUID.txCharacteristic, buffer, buffer.Length, false, null);
        }
        else if (BluetoothType == BluetoothGeneration.Classic)
        {
            if (SerialPortCTRL.port == null) throw new TimeoutException();
            if (debug) BluetoothLEHardwareInterface.Log("WriteLine : " + data);
            SerialPortCTRL.port.WriteLine(data);
        }
    }

    public override void SetBaudrate(int baudrate)
    {
        base.SetBaudrate(baudrate);

        if (BluetoothType == BluetoothGeneration.Classic)
            SerialPortCTRL.port.BaudRate = baudrate;

    }
    public override int GetBaudrate()
    {
        if (BluetoothType == BluetoothGeneration.BLE)
            return SerialPortCTRL.DEFAULT_BAUDRATE;
        else if (BluetoothType == BluetoothGeneration.Classic)
            return SerialPortCTRL.port.BaudRate;

        return SerialPortCTRL.DEFAULT_BAUDRATE;
    }


    protected override IEnumerator _ReopenMagicString(bool magicString)
    {
        if (magicString)
        {
            try
            {
                SerialPortCTRL.port.DtrEnable = false;
                Write(Keyword.Command.CM9X);
            }
            catch (Exception e) { Debug.LogWarning(e); }
        }

        yield return null; // magic string sending delay.

        try { SerialPortCTRL.port.Close(); }
        catch (Exception) { }

        yield return new WaitForSeconds(0.5f);

        try
        {
            SerialPortCTRL.port.Open();
            SerialPortCTRL.port.DtrEnable = true;
            WriteLine(string.Empty);
        }
        catch (Exception) { MotionCommanderBase.OnError(COMM_RESULT.TX_FAIL); }
    }

    void OnNotifyState(string state)
    {
        BluetoothLEHardwareInterface.Log("OnNotifyState : " + state);
    }
    void OnReceiveData(string characteristic, byte[] data)
    {
        for (int ix = 0; ix < data.Length; ix++) readBuffer.Enqueue(data[ix]);
    }
}
#endif